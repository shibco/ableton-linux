/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Copyright (C) 2026 PipeASIO contributors
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/* Backend-agnostic audio API surface for PipeASIO. */
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* Opaque handles */

typedef struct audio_client audio_client_t;
typedef struct audio_port   audio_port_t;

/* Value types */

typedef uint32_t audio_nframes_t;
typedef float    audio_sample_t;

typedef struct
{
    audio_nframes_t min;
    audio_nframes_t max;
} audio_latency_range_t;

typedef struct
{
    char     node_name[256];
    char     port_name[256];
    char     key[256];
    uint32_t node_id;
    uint32_t port_id;
    uint32_t direction;
    uint32_t global_port_id;
} audio_endpoint_t;

typedef enum
{
    AUDIO_CAPTURE_LATENCY  = 0,
    AUDIO_PLAYBACK_LATENCY = 1,
} audio_latency_mode_t;

/* Callback signatures */

/* Returns 0 when the ASIO host consumed the cycle, nonzero when it did not (no
 * buffers, or stopped).  The backend uses this to tell a real xrun apart from
 * the idle cycles of a deliberate Stop. */
typedef int (*audio_process_cb)(audio_nframes_t nframes, void *arg);
typedef int (*audio_sample_rate_cb)(audio_nframes_t nframes, void *arg);

/* Constants */

/* audio_open option flags */
#define AUDIO_NULL_OPTION 0x00u
#define AUDIO_NO_START_SERVER 0x01u

/* Append-only values shared by the WoW64 PE and unixlib. */
#define AUDIO_STATUS_OK 0u
#define AUDIO_STATUS_ERROR 1u
#define AUDIO_STATUS_NO_MEMORY 2u
#define AUDIO_STATUS_NO_CONTEXT 3u
#define AUDIO_STATUS_NO_DAEMON 4u
#define AUDIO_STATUS_NO_UNIXLIB 5u

/* audio_port_register / audio_get_device_ports flag bits */
#define AUDIO_PORT_IS_INPUT 0x01u
#define AUDIO_PORT_IS_OUTPUT 0x02u
#define AUDIO_PORT_IS_PHYSICAL 0x04u

/* Lifecycle */

audio_client_t *audio_open(const char *client_name, uint32_t options, uint32_t *status);
bool            audio_close(audio_client_t *client);
bool            audio_activate(audio_client_t *client);
bool            audio_deactivate(audio_client_t *client);
const char     *audio_get_client_name(audio_client_t *client);

/* Properties */

audio_nframes_t audio_get_sample_rate(audio_client_t *client);
audio_nframes_t audio_get_buffer_size(audio_client_t *client);
bool            audio_set_buffer_size(audio_client_t *client, audio_nframes_t nframes);

/* Pin the graph sample rate (FORCE_RATE) on the next audio_activate.
 * rate == 0 means follow the PipeWire graph (no FORCE_RATE). */
void audio_set_forced_rate(audio_client_t *client, audio_nframes_t rate);

/* When set, the next audio_activate does NOT pin the graph quantum
 * (PW_KEY_NODE_FORCE_QUANTUM): the filter becomes a follower so the target
 * device (e.g. a Bluetooth sink whose clock cannot be slaved) drives the cycle.
 * Default off. Wired devices keep the forced low-latency quantum. */
void audio_set_follow_device(audio_client_t *client, bool follow);

/* Select SCHED_FIFO for the next data-loop start. Call while the loop is stopped. */
void audio_set_realtime(audio_client_t *client, bool realtime);

/* Most recent graph quantum (clock.duration) the process callback observed
 * while following a device, or 0 if none seen yet. Lets the ASIO side settle
 * its buffer size to the device-dictated quantum. */
audio_nframes_t audio_observed_quantum(audio_client_t *client);

/* Nanosecond timestamp (PipeWire graph clock) of the most recent process cycle,
 * 0 before the first cycle. Feeds the ASIO host's systemTime. */
uint64_t audio_get_time_nsec(audio_client_t *client);

/* Ports */

audio_port_t *audio_port_register(audio_client_t *client, const char *port_name, uint64_t flags,
                                  uint32_t channel);
bool          audio_port_unregister(audio_client_t *client, audio_port_t *port);
void         *audio_port_get_buffer(audio_port_t *port, audio_nframes_t nframes);
/* Capacity in frames of the port's dequeued cycle buffer (datas[0].maxsize),
 * 0 when no buffer is mapped this cycle.  Lets the RT copy clamp against a
 * daemon buffer smaller than the host period (quantum < buffer_size). */
audio_nframes_t audio_port_buffer_avail_frames(const audio_port_t *port);
bool            audio_port_get_name(const audio_port_t *port, char *out, size_t size);
/* The returned NULL-terminated endpoint-key array owns all strings. */
const char **audio_get_device_ports(audio_client_t *client, const char *node_name, uint64_t flags);
bool audio_get_device_endpoints(audio_client_t *client, const char *node_name, uint64_t flags,
                                audio_endpoint_t *endpoints, uint32_t capacity, uint32_t *count);
bool audio_port_publish_output(audio_port_t *port, const audio_sample_t *source,
                               audio_nframes_t frames, bool admitted, bool active);
/* Returns and clears the "PipeWire default sink/source changed" flag (set when
 * the "default" metadata switches to a different node after the initial fill).
 * Lets the ASIO side trigger a reconnect when the user follows the default. */
bool audio_default_changed(audio_client_t *client);
/* Returns and clears the "a peer moved its SPA_PARAM_Latency" flag. The ASIO
 * side relays it as kAsioLatenciesChanged so a host re-reads GetLatencies
 * instead of compensating with a stale figure. */
bool audio_latency_changed(audio_client_t *client);
/* Combined graph latency for one direction, in samples: our own buffer period
 * plus whatever the connected device chain reports. */
void audio_port_get_latency_range(audio_port_t *port, uint32_t mode, audio_latency_range_t *range);

/* Callbacks */

bool audio_set_process_callback(audio_client_t *client, audio_process_cb cb, void *arg);
bool audio_set_sample_rate_callback(audio_client_t *client, audio_sample_rate_cb cb, void *arg);

/* Connections / memory */

bool audio_connect(audio_client_t *client, const char *src, const char *dst);
void audio_free(void *ptr);
/* Frees an array returned by audio_get_device_ports, including its strings. */
void audio_free_ports(const char **ports);
